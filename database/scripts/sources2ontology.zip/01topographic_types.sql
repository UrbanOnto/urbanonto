INSERT INTO ontology.topographic_types SELECT * FROM ontology_sources.topographic_types;
