INSERT INTO ontology.topographic_objects SELECT * FROM ontology_sources.topographic_objects;
